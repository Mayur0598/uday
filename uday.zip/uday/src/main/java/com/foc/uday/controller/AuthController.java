package com.foc.uday.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.foc.uday.security.JWTHelper;
import com.foc.uday.security.auth.AuthRequest;
import com.foc.uday.security.auth.AuthResponse;
import com.foc.uday.security.auth.UserInfoDetails;

@RestController
public class AuthController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	JWTHelper jwtHelper;

	@PostMapping("/login")
	public AuthResponse login(@RequestBody AuthRequest authRequest) {

		AuthResponse result = null;

		Authentication authentication = authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(authRequest.getUserName(), authRequest.getPassword()));

		if (authentication.isAuthenticated()) {

			Map<String, Object> map = new HashMap<String, Object>();
			UserInfoDetails userDetails = (UserInfoDetails) authentication.getPrincipal();
			map.put("userDetails", userDetails);
			result = new AuthResponse(jwtHelper.generateToken(map, authRequest.getUserName()));
		} else {
			throw new UsernameNotFoundException("Bad Credentials");
		}
		return result;
	}
}
