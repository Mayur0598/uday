package com.foc.uday.security.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.foc.uday.entity.User;

import org.springframework.security.crypto.password.PasswordEncoder;

@Service
public class UserInfoService implements UserDetailsService {

	@Autowired
	private UserInfoRepository userInfoRepository;

	@Autowired
	private PasswordEncoder encoder;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

		UserInfoDetails result = null;

		User userDetails = userInfoRepository.findByPhone(username);

		if (userDetails != null) {
			result = new UserInfoDetails(userDetails);
		} else {
			throw new UsernameNotFoundException("Invalid credentials");
		}

		return result;

	}

}
