package com.foc.uday.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "domain_object")
@Getter
@Setter
public class DomainObject {

	@Id
	@Column(name = "domain_object_id")
	private Integer domainObjectId;

	@Column(name = "name")
	private String name;

}
