 	package com.foc.uday;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdayApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdayApplication.class, args);
	}

}
