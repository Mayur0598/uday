package com.foc.uday.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.foc.uday.security.JWTHelper;
import com.foc.uday.security.auth.AuthRequest;
import com.foc.uday.security.auth.UserInfoService;
import com.google.gson.Gson;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
public class TestController {
	@Autowired
	JWTHelper jwtHelper;

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	UserInfoService userInfoService;

	@PostMapping("/test")
	public String test() {
		return new Gson().toJson(userInfoService.loadUserByUsername("9766843275"));
	}

	@PostMapping("/pass")
	public String getEncodedPassword() {
		return encoder.encode("Mayur@1123");
	}

	@PostMapping("/home")
	public String home() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return "accessible";
	}

	@PostMapping("/pri")
	@PreAuthorize("hasAuthority('ADMIN')")
	public String pri(Principal user) {
		return user.getName();
	}
}
