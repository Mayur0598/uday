package com.foc.uday.util;

import java.util.stream.IntStream;

import org.springframework.web.client.RestTemplate;

public class DataEncryptionUtil {
	
	RestTemplate restTemplate;
	
	public void test() {
		IntStream.rangeClosed(0, 0);
	}

}
