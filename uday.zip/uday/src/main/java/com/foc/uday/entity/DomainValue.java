package com.foc.uday.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "domain_value")
public class DomainValue {

	@Id
	private Integer id;

	@Column(name = "value")
	private String value;
}
