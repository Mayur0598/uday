package com.foc.uday.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@PostMapping("/getDetailsForDashboard")
	public void getDetailsForDashboard() {
	}

	@PostMapping("/getDetailsForDashboard")
	public void getBatchDetailsForDashboard() {

	}

	@PostMapping("/getMentorListInBatch")
	public void getMentorListInBatch() {

	}

	@PostMapping("/getMenteeListInBatch")
	public void getMenteeListInBatch() {

	}

	@PostMapping("/addMentorToBatch")
	public void addMentorToBatch() {

	}

	@PostMapping("/addMenteeToBatch")
	public void addMenteeToBatch() {

	}
}
