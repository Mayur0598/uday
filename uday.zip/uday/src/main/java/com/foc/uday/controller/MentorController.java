package com.foc.uday.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/mentor")
public class MentorController {

	@PostMapping("/getDetailsForDashboard")
	public void getDetailsForDashboard() {
	}

	@PostMapping("/getProfileDetails")
	public void getProfileDetails() {

	}

	@PostMapping("/logSession")
	public void logSession() {

	}

	@PostMapping("/logFeedbackForSession")
	public void logFeedbackForSession() {

	}
}
