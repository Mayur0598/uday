CREATE TABLE `domain_object` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `domain_value` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `domain_object_fk` int(10) unsigned NOT NULL,
  `value` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `domain_object_fk` (`domain_object_fk`,`value`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gender_domain_value_fk` int(11) NOT NULL,
  `role_domain_value_fk` int(11) NOT NULL,
  `logged_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `rowstate` tinyint(3) unsigned DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `mentor` (
  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_fk` INTEGER UNSIGNED NOT NULL,
  `profession` VARCHAR(20) NOT NULL,
  `organization` VARCHAR(20) NOT NULL,
  `education` VARCHAR(20) NOT NULL,
  `experience_in_years` TINYINT NOT NULL,
  `number_of_mentees_preferred` TINYINT DEFAULT 1,
  `created_by_admin_id` INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


CREATE TABLE `batch` (
  `batch_id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_by_admin_id` INTEGER UNSIGNED NOT NULL,
  `start` VARCHAR(20) NOT NULL,
  `end` VARCHAR(20) DEFAULT NULL,
  `is_batch_closed` TINYINT DEFAULT 0,
  PRIMARY KEY (`batch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT, 
  `user_fk` INTEGER UNSIGNED NOT NULL,
  `original_region` VARCHAR(20) NOT NULL,
  `current_region` VARCHAR(20) NOT NULL,
  `course` VARCHAR(20) NOT NULL,
  `stream` VARCHAR(20) NOT NULL,
  `college` VARCHAR(20) NOT NULL,
  `created_by_admin_id` INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `session`;
CREATE TABLE `session` (
  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `mentor_fk` INTEGER UNSIGNED NOT NULL,
  `student_fk` INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `session_details`;
CREATE TABLE `session_details` (
  `id` INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  `session_fk` INTEGER UNSIGNED NOT NULL,
  `start` TIMESTAMP NOT NULL,
  `end` TIMESTAMP NOT NULL,
  `rating` TINYINT,
  `feedback` VARCHAR(250),
  `recording_link` VARCHAR(50),
  `is_batch_closed` TINYINT DEFAULT 0,
  PRIMARY KEY (`session_details_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `mentor_batch_mapping`;
CREATE TABLE `mentor_batch_mapping` (
  `mentor_fk` INTEGER UNSIGNED NOT NULL,
  `batch_fk` INTEGER UNSIGNED NOT NULL,
  `logged_date` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `rowstate` TINYINT UNSIGNED DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `student_mentor_mapping`;
CREATE TABLE `student_mentor_mapping` (
  `mentor_id` INTEGER UNSIGNED NOT NULL,
  `student_id` INTEGER UNSIGNED NOT NULL,
  `rowstate` TINYINT UNSIGNED DEFAULT 1,
  FOREIGN KEY (`mentor_id`) REFERENCES `mentor`(`user_id`),
  FOREIGN KEY (`student_id`) REFERENCES `student`(`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `user_id` INTEGER UNSIGNED NOT NULL,
  FOREIGN KEY (`user_id`) REFERENCES `user`(`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

